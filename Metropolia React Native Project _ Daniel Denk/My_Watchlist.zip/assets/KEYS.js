// File containing API keys

const API_KEY = "3ed4699d"

export default API_KEY